
import glob
from PIL import Image

file = 'test.txt'

with open(file, 'w', encoding='utf-8') as file:
    for filename in glob.glob('*.jpg'): #assuming gif
        file.write("/content/darknet/test/" + filename + "\n")
